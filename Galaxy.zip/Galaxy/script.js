// Обработка формы входа
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Вход выполнен успешно! Добро пожаловать в GalaxyTravel!');
        window.location.href = 'index.html';
    });
}

// Обработка формы регистрации
const registerForm = document.getElementById('registerForm');
if (registerForm) {
    registerForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const password = document.getElementById('password');
        const confirmPassword = document.getElementById('confirmPassword');
        
        // Проверка сложности пароля
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
        if (!passwordRegex.test(password.value)) {
            alert('Пароль должен содержать не менее 8 символов, включая заглавные и строчные буквы, а также цифры');
            return;
        }
        
        if (password.value !== confirmPassword.value) {
            alert('Пароли не совпадают!');
            return;
        }
        
        // Проверка возраста
        const birthdate = new Date(document.getElementById('birthdate').value);
        const today = new Date();
        const age = today.getFullYear() - birthdate.getFullYear();
        
        if (age < 18) {
            alert('Для регистрации необходимо быть старше 18 лет');
            return;
        }
        
        // Проверка роста и веса
        const height = parseInt(document.getElementById('height').value);
        const weight = parseInt(document.getElementById('weight').value);
        
        if (height < 150 || height > 200) {
            alert('Рост должен быть в диапазоне от 150 до 200 см');
            return;
        }
        
        if (weight < 50 || weight > 120) {
            alert('Вес должен быть в диапазоне от 50 до 120 кг');
            return;
        }
        
        alert('Заявка успешно отправлена! Наш специалист свяжется с вами в течение 3 рабочих дней.');
        window.location.href = 'index.html';
    });
}

// Выпадающее меню
document.addEventListener('DOMContentLoaded', function() {
    const dropdownToggles = document.querySelectorAll('.dropdown-toggle');
    
    dropdownToggles.forEach(toggle => {
        toggle.addEventListener('click', function(e) {
            e.stopPropagation();
            const dropdownMenu = this.nextElementSibling;
            dropdownMenu.classList.toggle('show');
        });
    });

    // Закрытие меню при клике вне его
    document.addEventListener('click', function() {
        document.querySelectorAll('.dropdown-menu').forEach(menu => {
            menu.classList.remove('show');
        });
    });
});

// Плавная прокрутка для якорей
document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        if (href !== '#' && href.startsWith('#')) {
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                target.scrollIntoView({ 
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        }
    });
});

// Анимация при прокрутке
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
        }
    });
}, observerOptions);

// Наблюдаем за элементами для анимации
document.addEventListener('DOMContentLoaded', function() {
    // Анимация для элементов направлений
    document.querySelectorAll('.destination-item').forEach(item => {
        observer.observe(item);
    });
    
    // Анимация для заголовков
    document.querySelectorAll('h2, h3').forEach(heading => {
        observer.observe(heading);
    });
    
    // Анимация для секций
    document.querySelectorAll('section').forEach(section => {
        if (!section.classList.contains('hero')) {
            observer.observe(section);
        }
    });
});